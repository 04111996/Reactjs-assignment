import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

import { userActions } from '../_actions';

class HomePage extends React.Component {
    constructor(props) {
        super(props);
    this.state = { 
        clicked : false
    };
    this.handleLocalStorageData = this.handleLocalStorageData.bind(this);
    }
    
    handleLocalStorageData(event){
        this.setState({ clicked: true });
    }
    
    render() {
        const { user, users } = this.props;
        const { clicked } = this.state;
        return (
            <div className="col-md-6 col-md-offset-3">
                <h1>Hi {user.firstName}</h1><span className="view-align"> <button onClick={this.handleLocalStorageData}>View Profile</button></span>
                <p>You're logged in with React User Wizard application</p>
                <h3> Click View button to see Logged in users Profile:</h3>

                {clicked ?
                <ul>
                    <li>
                        First Name:<b> {user.firstName}</b><br/>
                        Last Name: <b> {user.lastName}</b><br/>
                        Address:<b> {user.address}</b><br/>
                        City:<b> {user.city}</b><br/>
                        EmailAddress:<b> {user.username}</b><br/>
                        Image: <b> {user.image}</b><br/>
                    </li>
                </ul>:null}  
                <p>
                    <Link to="/login">Logout</Link>
                </p>
              
            </div>
        );
    }
}

function mapStateToProps(state) {
    const { users, authentication } = state;
    const { user } = authentication;
    return {
        user,
        users
    };
}

const connectedHomePage = connect(mapStateToProps)(HomePage);
export { connectedHomePage as HomePage };